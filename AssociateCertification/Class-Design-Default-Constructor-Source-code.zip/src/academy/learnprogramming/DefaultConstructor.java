package academy.learnprogramming;

/**
 * @author goran on 14/07/2017.
 */
public class DefaultConstructor {

    public static void main(String[] args) {
//        Dog dog = new Dog();
    }
}
