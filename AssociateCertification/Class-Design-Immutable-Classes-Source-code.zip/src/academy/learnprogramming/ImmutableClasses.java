package academy.learnprogramming;

/**
 * @author goran on 14/07/2017.
 */
public class ImmutableClasses {

    public static void main(String[] args) {

    }
}
