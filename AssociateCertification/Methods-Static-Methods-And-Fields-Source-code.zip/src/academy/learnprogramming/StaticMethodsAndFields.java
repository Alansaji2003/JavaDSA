package academy.learnprogramming;

/**
 * @author goran on 12/07/2017.
 */
public class StaticMethodsAndFields {

    public static int myNumber = 10;

    public static void main(String[] args) {
        System.out.println(myNumber);
    }
}
