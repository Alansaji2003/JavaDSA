package academy.learnprogramming;

/**
 * @author goran on 12/07/2017.
 */
public class AnotherMain {

    public static void main(String[] args) {
        System.out.println("print in another main");
    }
}
