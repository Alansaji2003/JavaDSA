package academy.learnprogramming;

/**
 * @author goran on 14/07/2017.
 */
public class Dog extends Animal {

    public Dog(int age) {
        super(age);
        System.out.println("Dog");

    }
}
