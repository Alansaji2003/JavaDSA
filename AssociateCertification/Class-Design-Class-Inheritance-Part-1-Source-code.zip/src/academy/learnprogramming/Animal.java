package academy.learnprogramming;

/**
 * @author goran on 14/07/2017.
 */
public class Animal {

    private int age;

    public Animal(int age) {
        System.out.println("Animal");
        this.age = age;
    }
}
