package academy.learnprogramming;

/**
 * @author goran on 18/07/2017.
 */
public interface Hop {

    static int getAverageJumpHeight() {
        return 2;
    }
}
