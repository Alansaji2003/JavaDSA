package academy.learnprogramming;

/**
 * @author goran on 15/07/2017.
 */
public interface Omnivore extends Herbivore, Carnivore{

//    void eatPlants();
//    void eatMeat();
}
