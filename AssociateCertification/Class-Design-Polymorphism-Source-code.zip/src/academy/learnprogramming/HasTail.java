package academy.learnprogramming;

/**
 * @author goran on 15/07/2017.
 */
public interface HasTail {

//    public static final int DEFAULT_TAIL_LENGTH = 2;
    int DEFAULT_TAIL_LENGTH = 2;

//    public int getTailLength();
//    public abstract int getTailLength();
    int getTailLength();

//    int getWeight() {}
}
