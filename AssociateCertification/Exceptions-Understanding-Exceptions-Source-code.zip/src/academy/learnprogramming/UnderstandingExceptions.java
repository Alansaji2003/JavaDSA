package academy.learnprogramming;

/**
 * @author goran on 21/07/2017.
 */
public class UnderstandingExceptions {

    public static void main(String[] args) {
        int[] myArray = new int[2];
        System.out.println(myArray[5]);
    }
}
